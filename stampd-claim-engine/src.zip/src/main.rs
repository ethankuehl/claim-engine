use std::io::Write;
use std::env;
use std::net::Ipv4Addr;
use actix_multipart::{
    form::{
        tempfile::{TempFile, TempFileConfig},
        MultipartForm
    },
    Multipart
};
use actix_web::{middleware, web, post, App, Error, HttpResponse, HttpServer, Responder};
use futures_util::TryStreamExt as _;
use uuid::Uuid;
use std::fs;
use reqwest::multipart::Part;
use log;
use env_logger;
// use tokio::fs::File;
use std::fs::File;
use std::io::Read;
mod c2pa_func;

#[derive(Debug, MultipartForm)]
struct UploadForm {
    #[multipart(rename = "file")]
    files: Vec<TempFile>,
}

#[post("/api/http_example")]
async fn http_example(
    MultipartForm(form): MultipartForm<UploadForm>,
) -> HttpResponse {
    let mut file_path_vec = Vec::new();
    let mut file_path = "".to_string();
    let mut signed_file_path = "".to_string();
    let mut file_name = "".to_string();

    for f in form.files {
        file_name = f.file_name.unwrap();
        file_path = format!("./original/{}", file_name.clone());
        // signed_file_path = format!("./signed/{}", file_name.clone());
        file_path_vec.push(file_path.clone());
        // file_path_vec.push(signed_file_path.clone());
        println!("{}", file_path.clone());
        log::info!("saving to {}", file_path.clone());
        f.file.persist(file_path.clone()).unwrap();
        
    }
    println!("Uploaded file");
    signed_file_path = format!("./signed/{}", file_name.clone());
    println!("{}", signed_file_path);
    file_path_vec.push(signed_file_path.clone());
    let _ = fs::copy(file_path.clone(), signed_file_path.clone());

    let _ = c2pa_func::generate_claim(file_path_vec).await;

    let mut file = File::open(signed_file_path.clone()).unwrap();
    let mut vec = Vec::new(); 
    let _ = file.read_to_end(&mut vec);
    HttpResponse::Ok().content_type("image/png").body(vec)
    // HttpResponse::Ok().body(form)
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    env_logger::init_from_env(env_logger::Env::new().default_filter_or("info"));

    log::info!("creating temporary upload directory");
    std::fs::create_dir_all("./original")?;
    std::fs::create_dir_all("./signed")?;

    log::info!("starting HTTP server at http://localhost:8080");

    let port_key = "FUNCTIONS_CUSTOMHANDLER_PORT";
    let port: u16 = match env::var(port_key) {
        Ok(val) => val.parse().expect("Custom Handler port is not a number!"),
        Err(_) => 3000,
    };
    HttpServer::new(|| {
        App::new()
            .service(http_example)
    })
    .bind((Ipv4Addr::UNSPECIFIED, port))?
    .run()
    .await
}
